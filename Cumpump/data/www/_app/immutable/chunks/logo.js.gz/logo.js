const o=""+new URL("../assets/logo.png",import.meta.url).href;export{o as l};
